import logging

from fastapi import APIRouter

# Initialize FastAPI router
router = APIRouter()
logger = logging.getLogger(__name__)
