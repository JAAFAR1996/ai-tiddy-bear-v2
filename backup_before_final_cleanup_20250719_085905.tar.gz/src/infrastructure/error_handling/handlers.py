"""Error handling utilities and standardized response formatting."""

import traceback
from datetime import datetime
from typing import Any

from src.infrastructure.logging_config import get_logger

from .exceptions import AITeddyError

logger = get_logger(__name__, component="infrastructure")


class ErrorHandler:
    """Centralized error handling and response formatting."""

    def __init__(self, log_errors: bool = True, include_details: bool = False):
        """Initialize error handler.

        Args:
            log_errors: Whether to log errors automatically
            include_details: Whether to include detailed error info in responses
        """
        self.log_errors = log_errors
        self.include_details = include_details

    def handle_error(
        self,
        error: Exception,
        context: dict[str, Any] | None = None,
        user_id: str | None = None,
        child_id: str | None = None,
    ) -> dict[str, Any]:
        """Handle an error and return a standardized response.

        Args:
            error: The exception that occurred
            context: Additional context information
            user_id: ID of the user (for logging)
            child_id: ID of the child (for logging, will be anonymized)

        Returns:
            Standardized error response dictionary
        """
        # Log the error if enabled
        if self.log_errors:
            self._log_error(error, context, user_id, child_id)

        # Create standardized response
        if isinstance(error, AITeddyError):
            return self._handle_aiteddy_error(error)
        return self._handle_generic_error(error)

    def _handle_aiteddy_error(self, error: AITeddyError) -> dict[str, Any]:
        """Handle AI Teddy specific errors."""
        response = {
            "error": True,
            "error_code": error.error_code,
            "message": error.message,
            "timestamp": datetime.utcnow().isoformat(),
            "http_status": error.http_status,
        }
        if self.include_details and error.details:
            response["details"] = error.details
        return response

    def _handle_generic_error(self, error: Exception) -> dict[str, Any]:
        """Handle generic, unexpected errors."""
        response = {
            "error": True,
            "error_code": "INTERNAL_SERVER_ERROR",
            "message": "An unexpected error occurred. Our team has been notified.",
            "timestamp": datetime.utcnow().isoformat(),
            "http_status": 500,
        }
        if self.include_details:
            response["details"] = {
                "error_type": type(error).__name__,
                "error_message": str(error),
            }
        return response

    def _log_error(
        self,
        error: Exception,
        context: dict[str, Any] | None,
        user_id: str | None,
        child_id: str | None,
    ):
        """Log error details."""
        log_level = (
            "error"
            if not isinstance(error, AITeddyError) or error.http_status >= 500
            else "warning"
        )

        log_data = {
            "error_type": type(error).__name__,
            "error_message": str(error),
            "context": context or {},
            "user_id": user_id,
            "child_id": (
                f"child_{hash(child_id)}" if child_id else None
            ),  # Anonymize child ID
            "traceback": (traceback.format_exc() if log_level == "error" else None),
        }

        if isinstance(error, AITeddyError):
            log_data["error_code"] = error.error_code
            log_data["details"] = error.details

        getattr(logger, log_level)(
            f"Error handled: {type(error).__name__}", extra=log_data
        )


def get_error_response(
    error: AITeddyError | Exception, include_details: bool = False
) -> dict[str, Any]:
    """Generate a standardized error response dictionary.

    Args:
        error: The exception object.
        include_details: Whether to include detailed error information.

    Returns:
        A dictionary representing the standardized error response.
    """
    handler = ErrorHandler(log_errors=False, include_details=include_details)
    return handler.handle_error(error)
