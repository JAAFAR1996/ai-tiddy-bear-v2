"""Security Validator for AI Teddy Bear v5.

Comprehensive security validation for child safety compliance,
COPPA regulations, and international standards.
"""

import re
from typing import Dict, List, Optional, Set, Tuple, Any
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
import hashlib
import secrets

from src.infrastructure.logging_config import get_logger

logger = get_logger(__name__, component="security-validator")


class SecurityLevel(Enum):
    """Security levels for different operational contexts."""
    
    DEVELOPMENT = "development"
    STAGING = "staging"
    PRODUCTION = "production"
    CHILD_SAFETY_ENHANCED = "child_safety_enhanced"


class ComplianceStandard(Enum):
    """International compliance standards."""
    
    COPPA = "COPPA"  # Children's Online Privacy Protection Act (USA)
    GDPR_K = "GDPR-K"  # GDPR for Kids (EU)
    PIPEDA = "PIPEDA"  # Personal Information Protection (Canada)
    LGPD = "LGPD"  # Lei Geral de Proteção de Dados (Brazil)
    CCPA = "CCPA"  # California Consumer Privacy Act


@dataclass
class ValidationResult:
    """Result of a security validation check."""
    
    is_valid: bool
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    
    def add_error(self, error: str) -> None:
        """Add an error message."""
        self.errors.append(error)
        self.is_valid = False
        
    def add_warning(self, warning: str) -> None:
        """Add a warning message."""
        self.warnings.append(warning)


@dataclass
class SecurityContext:
    """Context for security validation."""
    
    user_age: Optional[int] = None
    country_code: Optional[str] = None
    parent_consent: bool = False
    session_id: Optional[str] = None
    device_id: Optional[str] = None
    interaction_type: Optional[str] = None
    security_level: SecurityLevel = SecurityLevel.PRODUCTION


class SecurityValidator:
    """
    Comprehensive security validator for AI Teddy Bear v5.
    
    Ensures compliance with child safety regulations and
    international data protection standards.
    """
    
    # Sensitive data patterns that should never be collected from children
    SENSITIVE_PATTERNS = {
        'email': re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'),
        'phone': re.compile(r'[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{4,6}'),
        'ssn': re.compile(r'\b\d{3}-\d{2}-\d{4}\b|\b\d{9}\b'),
        'credit_card': re.compile(r'\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b'),
        'address': re.compile(r'\d+\s+[A-Za-z\s]+(?:Street|St|Avenue|Ave|Road|Rd|Boulevard|Blvd|Lane|Ln|Drive|Dr|Court|Ct|Plaza|Pl)'),
        'full_name': re.compile(r'\b[A-Z][a-z]+\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)?\b'),
    }
    
    # Prohibited content patterns
    PROHIBITED_CONTENT = {
        'profanity': re.compile(r'\b(?:bad|inappropriate|words|pattern)\b', re.IGNORECASE),
        'violence': re.compile(r'\b(?:kill|hurt|harm|attack|weapon)\b', re.IGNORECASE),
        'adult_content': re.compile(r'\b(?:adult|explicit|inappropriate)\b', re.IGNORECASE),
    }
    
    # Safe interaction patterns
    SAFE_INTERACTION_TYPES = {
        'story_telling', 'educational', 'game_playing', 'singing',
        'joke_telling', 'question_answering', 'language_learning'
    }
    
    def __init__(self, 
                 security_level: SecurityLevel = SecurityLevel.PRODUCTION,
                 compliance_standards: Optional[List[ComplianceStandard]] = None):
        """
        Initialize the security validator.
        
        Args:
            security_level: The security level to enforce
            compliance_standards: List of compliance standards to enforce
        """
        self.security_level = security_level
        self.compliance_standards = compliance_standards or [
            ComplianceStandard.COPPA,
            ComplianceStandard.GDPR_K
        ]
        self._initialize_validators()
        
    def _initialize_validators(self) -> None:
        """Initialize internal validators based on compliance standards."""
        self.validators = {
            ComplianceStandard.COPPA: self._validate_coppa_compliance,
            ComplianceStandard.GDPR_K: self._validate_gdpr_k_compliance,
            ComplianceStandard.PIPEDA: self._validate_pipeda_compliance,
            ComplianceStandard.LGPD: self._validate_lgpd_compliance,
            ComplianceStandard.CCPA: self._validate_ccpa_compliance,
        }
        
    def validate_interaction(self, 
                           content: str,
                           context: SecurityContext) -> ValidationResult:
        """
        Validate an interaction for security and compliance.
        
        Args:
            content: The content to validate
            context: The security context
            
        Returns:
            ValidationResult with detailed findings
        """
        result = ValidationResult(is_valid=True)
        
        # Check for sensitive data
        self._check_sensitive_data(content, result)
        
        # Check for prohibited content
        self._check_prohibited_content(content, result)
        
        # Validate age appropriateness
        self._validate_age_appropriateness(content, context, result)
        
        # Run compliance validators
        for standard in self.compliance_standards:
            if standard in self.validators:
                self.validators[standard](content, context, result)
                
        # Log validation result
        if not result.is_valid:
            logger.warning(
                f"Validation failed: {len(result.errors)} errors, "
                f"{len(result.warnings)} warnings",
                extra={
                    "errors": result.errors,
                    "warnings": result.warnings,
                    "session_id": context.session_id
                }
            )
            
        return result
        
    def _check_sensitive_data(self, content: str, result: ValidationResult) -> None:
        """Check for sensitive data patterns."""
        for data_type, pattern in self.SENSITIVE_PATTERNS.items():
            if pattern.search(content):
                result.add_error(
                    f"Detected potential {data_type} in content. "
                    f"Collection of {data_type} from children is prohibited."
                )
                
    def _check_prohibited_content(self, content: str, result: ValidationResult) -> None:
        """Check for prohibited content patterns."""
        for content_type, pattern in self.PROHIBITED_CONTENT.items():
            if pattern.search(content):
                result.add_warning(
                    f"Detected potential {content_type} content. "
                    "Content should be age-appropriate."
                )
                
    def _validate_age_appropriateness(self, 
                                    content: str,
                                    context: SecurityContext,
                                    result: ValidationResult) -> None:
        """Validate content is age-appropriate."""
        if context.user_age and context.user_age < 13:
            # Enhanced checks for younger children
            if len(content.split()) > 100:
                result.add_warning(
                    "Content may be too complex for young children. "
                    "Consider simplifying."
                )
                
    def _validate_coppa_compliance(self,
                                  content: str,
                                  context: SecurityContext,
                                  result: ValidationResult) -> None:
        """Validate COPPA compliance."""
        if not context.parent_consent and context.user_age and context.user_age < 13:
            result.add_error(
                "COPPA requires parental consent for children under 13"
            )
            
    def _validate_gdpr_k_compliance(self,
                                   content: str,
                                   context: SecurityContext,
                                   result: ValidationResult) -> None:
        """Validate GDPR-K compliance."""
        if context.user_age and context.user_age < 16:
            if not context.parent_consent:
                result.add_error(
                    "GDPR-K requires parental consent for children under 16"
                )
                
    def _validate_pipeda_compliance(self,
                                   content: str,
                                   context: SecurityContext,
                                   result: ValidationResult) -> None:
        """Validate PIPEDA compliance."""
        # Canadian privacy requirements
        pass
        
    def _validate_lgpd_compliance(self,
                                 content: str,
                                 context: SecurityContext,
                                 result: ValidationResult) -> None:
        """Validate LGPD compliance."""
        # Brazilian privacy requirements
        pass
        
    def _validate_ccpa_compliance(self,
                                 content: str,
                                 context: SecurityContext,
                                 result: ValidationResult) -> None:
        """Validate CCPA compliance."""
        # California privacy requirements
        pass
        
    def validate_session(self, session_data: Dict[str, Any]) -> ValidationResult:
        """
        Validate a complete session for security compliance.
        
        Args:
            session_data: Session data to validate
            
        Returns:
            ValidationResult
        """
        result = ValidationResult(is_valid=True)
        
        # Check session duration for child safety
        if 'duration_minutes' in session_data:
            duration = session_data['duration_minutes']
            if duration > 30:
                result.add_warning(
                    "Session exceeds recommended 30-minute limit for children"
                )
            if duration > 60:
                result.add_error(
                    "Session exceeds maximum 60-minute limit for child safety"
                )
                
        # Validate interaction types
        if 'interaction_types' in session_data:
            invalid_types = set(session_data['interaction_types']) - self.SAFE_INTERACTION_TYPES
            if invalid_types:
                result.add_error(
                    f"Invalid interaction types detected: {invalid_types}"
                )
                
        return result
        
    def generate_session_token(self, context: SecurityContext) -> str:
        """
        Generate a secure session token.
        
        Args:
            context: Security context
            
        Returns:
            Secure session token
        """
        # Generate cryptographically secure token
        token_data = f"{context.session_id}:{context.device_id}:{datetime.now(timezone.utc).isoformat()}"
        token_hash = hashlib.sha256(token_data.encode()).hexdigest()
        random_suffix = secrets.token_urlsafe(16)
        return f"{token_hash[:32]}-{random_suffix}"
        
    def validate_api_request(self, 
                           headers: Dict[str, str],
                           body: Optional[Dict[str, Any]] = None) -> ValidationResult:
        """
        Validate API request for security.
        
        Args:
            headers: Request headers
            body: Request body
            
        Returns:
            ValidationResult
        """
        result = ValidationResult(is_valid=True)
        
        # Validate required security headers
        required_headers = {
            'X-Child-Safety-Mode': 'enabled',
            'X-Request-ID': None,  # Just needs to exist
            'X-Session-Token': None,
        }
        
        for header, expected_value in required_headers.items():
            if header not in headers:
                result.add_error(f"Missing required header: {header}")
            elif expected_value and headers[header] != expected_value:
                result.add_error(
                    f"Invalid value for {header}: expected '{expected_value}'"
                )
                
        # Validate request body if present
        if body:
            # Check for sensitive data in request
            body_str = str(body)
            self._check_sensitive_data(body_str, result)
            
        return result
        
    def get_security_metrics(self) -> Dict[str, Any]:
        """
        Get current security metrics.
        
        Returns:
            Dictionary of security metrics
        """
        return {
            'security_level': self.security_level.value,
            'compliance_standards': [s.value for s in self.compliance_standards],
            'validators_active': len(self.validators),
            'timestamp': datetime.now(timezone.utc).isoformat()
        }


# Export all components
__all__ = [
    'SecurityValidator',
    'SecurityContext',
    'ValidationResult',
    'SecurityLevel',
    'ComplianceStandard'
]