"""Refactored Security Headers Middleware for AI Teddy Bear
Streamlined implementation using modular components for better maintainability.
"""

import time
import uuid
from typing import Any

from fastapi import Request, Response
from fastapi.middleware.base import BaseHTTPMiddleware
from starlette.middleware.base import RequestResponseEndpoint

from src.infrastructure.config.settings import get_settings
from src.infrastructure.logging_config import get_logger

logger = get_logger(__name__, component="middleware")


class SecurityHeadersBuilder:
    """Builds security headers for responses"""

    def __init__(self, is_production: bool = True):
        self.is_production = is_production

    def build_headers(self, request: Request) -> dict[str, str]:
        """Build security headers based on request context"""
        headers = {}

        # Content Security Policy
        headers["Content-Security-Policy"] = self._build_csp()

        # Security headers
        headers.update(
            {
                "X-Content-Type-Options": "nosniff",
                "X-Frame-Options": "DENY",
                "X-XSS-Protection": "1; mode=block",
                "Referrer-Policy": "strict-origin-when-cross-origin",
                "Permissions-Policy": self._build_permissions_policy(),
                "Cross-Origin-Opener-Policy": "same-origin",
                "Cross-Origin-Resource-Policy": "same-origin",
            }
        )

        # HSTS for production
        if self.is_production:
            headers["Strict-Transport-Security"] = (
                "max-age=31536000; includeSubDomains; preload"
            )

        # Child safety headers
        headers.update(
            {
                "X-Child-Safety-Mode": "enabled",
                "X-COPPA-Compliant": "true",
                "X-Parental-Control": "active",
            }
        )

        return headers

    def _build_csp(self) -> str:
        """Build Content Security Policy"""
        if self.is_production:
            # Strict CSP for production
            csp_directives = [
                "default-src 'self'",
                "script-src 'self'",
                "style-src 'self' 'unsafe-inline'",
                "img-src 'self' data: blob:",
                "connect-src 'self' wss: https:",
                "font-src 'self'",
                "object-src 'none'",
                "media-src 'self' blob:",
                "frame-src 'none'",
                "child-src 'none'",
                "worker-src 'self'",
                "form-action 'self'",
                "frame-ancestors 'none'",
                "base-uri 'self'",
                "upgrade-insecure-requests",
                "block-all-mixed-content",
            ]
        else:
            # Relaxed CSP for development
            csp_directives = [
                "default-src 'self'",
                "script-src 'self' 'unsafe-inline' 'unsafe-eval'",
                "style-src 'self' 'unsafe-inline'",
                "img-src 'self' data: blob: *",
                "connect-src 'self' ws: wss: *",
                "font-src 'self' *",
                "object-src 'none'",
                "media-src 'self' blob: *",
                "frame-src 'self'",
                "child-src 'self'",
                "worker-src 'self'",
                "form-action 'self'",
                "frame-ancestors 'self'",
                "base-uri 'self'",
            ]

        return "; ".join(csp_directives)

    def _build_permissions_policy(self) -> str:
        """Build Permissions Policy for child safety"""
        permissions = [
            "camera=()",  # No camera access
            "microphone=(self)",  # Microphone for voice features only
            "geolocation=()",  # No location access
            "payment=()",  # No payment features
            "usb=()",  # No USB access
            "accelerometer=()",  # No motion sensors
            "gyroscope=()",  # No gyroscope
            "magnetometer=()",  # No magnetometer
            "clipboard-read=()",  # No clipboard reading
            "clipboard-write=()",  # No clipboard writing
            "fullscreen=()",  # No fullscreen
            "picture-in-picture=()",  # No PIP
            "screen-wake-lock=()",  # No screen wake lock
            "web-share=()",  # No web share API
        ]
        return ", ".join(permissions)


def create_headers_builder(is_production: bool = True) -> SecurityHeadersBuilder:
    """Factory function to create headers builder"""
    return SecurityHeadersBuilder(is_production=is_production)


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """Streamlined security headers middleware for child safety.
    Uses modular components for better maintainability and testing.
    """

    def __init__(self, app) -> None:
        super().__init__(app)
        try:
            self.settings = get_settings()
            self.is_production = self.settings.application.ENVIRONMENT == "production"
        except Exception:
            # Fallback if settings are not available
            self.is_production = True
            logger.warning("Could not load settings, defaulting to production mode")

        self.headers_builder = create_headers_builder(self.is_production)
        logger.info(
            f"Security headers middleware initialized (production: {self.is_production})"
        )

    async def dispatch(
        self,
        request: Request,
        call_next: RequestResponseEndpoint,
    ) -> Response:
        """Process request and add security headers to response."""
        try:
            # Store start time for performance tracking
            request.state.start_time = time.time()
            request.state.request_id = str(uuid.uuid4())

            # Process the request
            response = await call_next(request)

            # Add security headers
            self._add_security_headers(response, request)

            return response
        except Exception as e:
            # Return safe error response with security headers
            logger.error(f"Error in security middleware: {e}")
            error_response = self._create_safe_error_response(str(e))
            self._add_security_headers(error_response, request)
            return error_response

    def _add_security_headers(self, response: Response, request: Request) -> None:
        """Add all required security headers."""
        # Get headers from builder
        headers = self.headers_builder.build_headers(request)

        # Apply headers to response
        for header_name, header_value in headers.items():
            response.headers[header_name] = header_value

        # Add request-specific headers
        self._add_request_specific_headers(response, request)

    def _add_request_specific_headers(
        self,
        response: Response,
        request: Request,
    ) -> None:
        """Add headers specific to the request context."""
        # Add request ID for tracking
        request_id = getattr(request.state, "request_id", str(uuid.uuid4()))
        response.headers["X-Request-ID"] = request_id

        # Add processing time
        start_time = getattr(request.state, "start_time", time.time())
        processing_time = round((time.time() - start_time) * 1000, 2)
        response.headers["X-Processing-Time"] = f"{processing_time}ms"

        # Child safety indicators
        child_id = self._extract_child_id(request)
        if child_id:
            response.headers["X-Child-Safety"] = "active"
            response.headers["X-COPPA-Compliant"] = "true"
            response.headers["X-Child-ID-Verified"] = "true"

        # Environment indicator
        if not self.is_production:
            response.headers["X-Development-Mode"] = "true"

    def _extract_child_id(self, request: Request) -> str | None:
        """Extract child ID from request if present."""
        try:
            # Check path parameters
            if hasattr(request, "path_params") and request.path_params:
                child_id = request.path_params.get("child_id")
                if child_id:
                    return child_id

            # Check query parameters
            if hasattr(request, "query_params") and request.query_params:
                child_id = request.query_params.get("child_id")
                if child_id:
                    return child_id

            # Check headers
            child_id_header = request.headers.get("X-Child-ID")
            if child_id_header:
                return child_id_header

        except Exception as e:
            logger.warning(f"Error extracting child_id: {e}")

        return None

    def _create_safe_error_response(self, error_msg: str) -> Response:
        """Create a safe error response with child-friendly messaging."""
        safe_message = "Oops! Something went wrong. Please try again later."

        # Don't expose internal error details to children
        error_response = {
            "error": safe_message,
            "child_safe": True,
            "status": "error",
            "timestamp": int(time.time()),
        }

        return Response(
            content=str(error_response).replace("'", '"'),  # Simple JSON-like format
            status_code=500,
            media_type="application/json",
        )

    def get_stats(self) -> dict[str, Any]:
        """Get middleware statistics"""
        return {
            "middleware": "SecurityHeadersMiddleware",
            "production_mode": self.is_production,
            "headers_builder": "active",
            "child_safety": "enabled",
            "coppa_compliant": True,
        }


def create_security_middleware(app) -> SecurityHeadersMiddleware:
    """Factory function to create security headers middleware."""
    return SecurityHeadersMiddleware(app)


# Export for easy imports
__all__ = [
    "SecurityHeadersBuilder",
    "SecurityHeadersMiddleware",
    "create_headers_builder",
    "create_security_middleware",
]
