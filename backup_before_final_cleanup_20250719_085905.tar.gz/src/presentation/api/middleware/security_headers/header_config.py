"""Security Headers Middleware
Main middleware class that coordinates security header application
while maintaining child safety and COPPA compliance.
"""

import time
import uuid
from typing import Any

from fastapi import Request, Response
from fastapi.middleware.base import BaseHTTPMiddleware
from starlette.middleware.base import RequestResponseEndpoint

from src.infrastructure.config.settings import get_settings
from src.infrastructure.logging_config import get_logger

from .header_builder import create_headers_builder
from .header_config import validate_config

logger = get_logger(__name__, component="middleware")


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """Provides comprehensive security headers for child safety and COPPA compliance.
    Now modular and maintainable with proper separation of concerns.
    """

    def __init__(self, app, config: dict[str, Any] | None = None) -> None:
        super().__init__(app)

        try:
            self.settings = get_settings()
            self.environment = getattr(
                self.settings.application, "ENVIRONMENT", "production"
            )
        except Exception as e:
            logger.warning(f"Could not load settings, using defaults: {e}")
            self.environment = "production"

        # Initialize headers builder
        try:
            self.headers_builder = create_headers_builder(self.environment)
        except ImportError:
            logger.warning("Header builder not available, using fallback")
            self.headers_builder = None

        # Validate configuration if builder is available
        if self.headers_builder:
            try:
                validation_results = validate_config(self.headers_builder.config)
                self._log_validation_results(validation_results)
            except Exception as e:
                logger.warning(f"Configuration validation failed: {e}")

        # Performance monitoring
        self.request_count = 0
        self.total_processing_time = 0.0

        logger.info(f"Security headers middleware initialized for {self.environment}")

    async def dispatch(
        self,
        request: Request,
        call_next: RequestResponseEndpoint,
    ) -> Response:
        """Process request and apply security headers.

        Args:
            request: Incoming HTTP request
            call_next: Next middleware / endpoint

        Returns:
            Response with security headers applied
        """
        # Track request
        start_time = time.time()
        request_id = str(uuid.uuid4())

        # Store request context
        request.state.request_id = request_id
        request.state.start_time = start_time

        try:
            # Process the request
            response = await call_next(request)

            # Apply security headers
            self._apply_security_headers(request, response)

            # Track performance
            self._track_performance(start_time)

            return response
        except Exception as e:
            logger.error(f"Security middleware error: {e}")

            # Still apply basic security headers even on error
            error_response = Response(
                content='{"error": "Something went wrong. Please try again later."}',
                status_code=500,
                media_type="application/json",
            )
            self._apply_basic_security_headers(error_response)
            return error_response

    def _apply_security_headers(self, request: Request, response: Response) -> None:
        """Apply all security headers to the response."""
        try:
            if self.headers_builder:
                # Build headers based on request context
                security_headers = self.headers_builder.build_all_headers(request)

                # Apply headers to response
                for name, value in security_headers.items():
                    response.headers[name] = value
            else:
                # Fallback to basic headers
                self._apply_basic_security_headers(response)

            # Apply special child safety measures
            if self._is_child_request(request):
                self._apply_enhanced_child_protection(response)

            # Add request tracking headers
            self._add_request_tracking_headers(request, response)

        except Exception as e:
            logger.error(f"Error applying security headers: {e}")
            # Fallback to basic headers
            self._apply_basic_security_headers(response)

    def _apply_basic_security_headers(self, response: Response) -> None:
        """Apply minimal essential security headers as fallback."""
        basic_headers = {
            "X-Frame-Options": "DENY",
            "X-Content-Type-Options": "nosniff",
            "X-XSS-Protection": "1; mode=block",
            "Referrer-Policy": "strict-origin-when-cross-origin",
            "X-Child-Safe": "1",
            "X-COPPA-Compliant": "1",
            "Content-Security-Policy": (
                "default-src 'self'; "
                "script-src 'self'; "
                "style-src 'self' 'unsafe-inline'; "
                "img-src 'self' data: blob:; "
                "connect-src 'self' wss:; "
                "font-src 'self'; "
                "object-src 'none'; "
                "media-src 'self' blob:; "
                "frame-src 'none'; "
                "frame-ancestors 'none'"
            ),
            "Permissions-Policy": (
                "camera=(), "
                "microphone=(self), "
                "geolocation=(), "
                "payment=(), "
                "usb=(), "
                "bluetooth=()"
            ),
        }

        for name, value in basic_headers.items():
            response.headers[name] = value

    def _apply_enhanced_child_protection(self, response: Response) -> None:
        """Apply enhanced protection for child users."""
        child_headers = {
            "X-Enhanced-Safety": "enabled",
            "X-Content-Rating": "family-friendly",
            "X-Parental-Controls": "active",
            "X-AI-Safety": "child-mode",
            "X-Voice-Processing": "supervised",
            "X-Emergency-Contact": "available",
            "Cache-Control": "no-store, must-revalidate, no-cache, private",
            "Pragma": "no-cache",
            "Expires": "0",
        }

        for name, value in child_headers.items():
            response.headers[name] = value

    def _add_request_tracking_headers(
        self, request: Request, response: Response
    ) -> None:
        """Add request tracking and performance headers."""
        # Add request ID for tracking
        request_id = getattr(request.state, "request_id", "unknown")
        response.headers["X-Request-ID"] = request_id

        # Add processing time
        start_time = getattr(request.state, "start_time", time.time())
        processing_time = round((time.time() - start_time) * 1000, 2)
        response.headers["X-Processing-Time"] = f"{processing_time}ms"

        # Add environment indicator
        response.headers["X-Environment"] = self.environment

        # Add safety timestamp
        response.headers["X-Safety-Check"] = str(int(time.time()))

    def _is_child_request(self, request: Request) -> bool:
        """Check if request is from a child user."""
        try:
            # Check for child indicators in request state
            user = getattr(request.state, "user", None)
            if user and user.get("role") == "child":
                return True

            # Check query parameters for child age
            child_age = request.query_params.get("child_age")
            if child_age:
                try:
                    age = int(child_age)
                    return age <= 13  # COPPA age limit
                except (ValueError, TypeError):
                    pass

            # Check for child_id parameter
            if "child_id" in request.query_params:
                return True

            # Check path for child endpoints
            child_endpoints = [
                "/api/v1/children",
                "/api/v1/process-audio",
                "/esp32",
                "/api/v1/conversations",
            ]

            if any(
                request.url.path.startswith(endpoint) for endpoint in child_endpoints
            ):
                return True

            # Check headers for child device
            device_id = request.headers.get("X-Device-ID", "")
            if device_id.startswith("teddy_"):
                return True

            # Check for child ID in headers
            if request.headers.get("X-Child-ID"):
                return True

        except Exception as e:
            logger.warning(f"Error checking child request: {e}")

        return False

    def _track_performance(self, start_time: float) -> None:
        """Track middleware performance metrics."""
        processing_time = time.time() - start_time
        self.request_count += 1
        self.total_processing_time += processing_time

        # Log performance every 1000 requests
        if self.request_count % 1000 == 0:
            avg_time = self.total_processing_time / self.request_count
            logger.info(
                f"Security middleware performance: "
                f"{self.request_count} requests, "
                f"avg {avg_time * 1000:.2f}ms per request"
            )

    def _log_validation_results(self, validation_results: dict[str, list]) -> None:
        """Log configuration validation results."""
        for error in validation_results.get("errors", []):
            logger.error(f"Security config error: {error}")

        for warning in validation_results.get("warnings", []):
            logger.warning(f"Security config warning: {warning}")

        for recommendation in validation_results.get("recommendations", []):
            logger.info(f"Security config recommendation: {recommendation}")

    def get_stats(self) -> dict[str, Any]:
        """Get middleware performance statistics."""
        avg_time = 0.0
        if self.request_count > 0:
            avg_time = self.total_processing_time / self.request_count

        stats = {
            "middleware": "SecurityHeadersMiddleware",
            "request_count": self.request_count,
            "average_processing_time_ms": round(avg_time * 1000, 2),
            "total_processing_time": round(self.total_processing_time, 2),
            "environment": self.environment,
            "headers_builder_available": self.headers_builder is not None,
        }

        # Add child safety info if builder is available
        if self.headers_builder and hasattr(self.headers_builder, "config"):
            stats.update(
                {
                    "child_safety_enabled": getattr(
                        self.headers_builder.config, "child_safety_mode", True
                    ),
                    "coppa_compliant": getattr(
                        self.headers_builder.config, "coppa_compliant", True
                    ),
                }
            )

        return stats

    def reset_stats(self) -> None:
        """Reset performance statistics."""
        self.request_count = 0
        self.total_processing_time = 0.0
        logger.info("Security middleware statistics reset")

    def get_child_safety_info(self) -> dict[str, Any]:
        """Get child safety specific information."""
        return {
            "child_protection": "enabled",
            "coppa_compliance": "active",
            "content_filtering": "strict",
            "parental_controls": "available",
            "emergency_contact": "enabled",
            "data_retention": "90-days",
            "privacy_mode": "child-protected",
        }


# Convenience function for easy setup
def create_security_middleware(
    app, environment: str = "production"
) -> SecurityHeadersMiddleware:
    """Create and configure security headers middleware.

    Args:
        app: FastAPI application instance
        environment: Environment configuration

    Returns:
        Configured SecurityHeadersMiddleware
    """
    return SecurityHeadersMiddleware(app)


# Alternative factory for AI Teddy Bear specific setup
def create_teddy_bear_security_middleware(app) -> SecurityHeadersMiddleware:
    """Create security middleware specifically configured for AI Teddy Bear.

    Args:
        app: FastAPI application instance

    Returns:
        SecurityHeadersMiddleware configured for maximum child safety
    """
    middleware = SecurityHeadersMiddleware(app)
    logger.info(
        "🧸 AI Teddy Bear security middleware created with enhanced child protection"
    )
    return middleware


# Export for easy imports
__all__ = [
    "SecurityHeadersMiddleware",
    "create_security_middleware",
    "create_teddy_bear_security_middleware",
]
