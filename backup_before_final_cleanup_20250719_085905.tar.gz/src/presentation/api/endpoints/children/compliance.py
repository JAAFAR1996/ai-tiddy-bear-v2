"""Children compliance endpoints with COPPA support."""
from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from src.infrastructure.security.hardening.coppa_compliance import (
    COPPACompliance,
    DataType,
    ConsentStatus,
    ComplianceLevel
)
from src.infrastructure.config.settings import Settings, get_settings
from src.infrastructure.logging_config import get_logger

logger = get_logger(__name__)
router = APIRouter()

# Request/Response Models
class ConsentRequest(BaseModel):
    """Parental consent request model."""
    child_id: str = Field(..., description="Child identifier")
    parent_id: str = Field(..., description="Parent identifier")
    data_types: List[str] = Field(..., description="Data types requiring consent")

class ConsentResponse(BaseModel):
    """Consent response model."""
    consent_id: str
    status: str
    expires_at: datetime

class ComplianceValidator:
    """Compliance validation service."""
    
    def __init__(self, settings: Settings):
        self.settings = settings
        self.coppa = COPPACompliance()
    
    def validate_age_compliance(self, age: int) -> dict:
        """Validate age compliance requirements."""
        return {
            "compliant": True,
            "requires_consent": age < 13,
            "compliance_level": str(ComplianceLevel.from_age(age))
        }
    
    def validate_data_collection(self, data_types: List[str], child_age: int) -> dict:
        """Validate data collection compliance."""
        if child_age < 13:
            allowed = [str(DataType.VOICE_INTERACTIONS), str(DataType.PREFERENCES)]
            disallowed = [dt for dt in data_types if dt not in allowed]
            
            return {
                "compliant": len(disallowed) == 0,
                "allowed_types": allowed,
                "disallowed_types": disallowed
            }
        
        return {
            "compliant": True,
            "allowed_types": data_types,
            "disallowed_types": []
        }

class ParentalConsentManager:
    """Parental consent management."""
    
    def __init__(self, coppa_service: COPPACompliance):
        self.coppa = coppa_service
    
    async def create_consent_record(
        self,
        child_id: str,
        parent_id: str,
        data_types: List[str]
    ) -> str:
        """Create consent record."""
        return await self.coppa.request_parental_consent(
            child_id, parent_id, data_types
        )
    
    async def revoke_consent(self, consent_id: str) -> bool:
        """Revoke existing consent."""
        # Implementation would update consent status
        return True

class DataRetentionManager:
    """Data retention management."""
    
    def __init__(self, coppa_service: COPPACompliance):
        self.coppa = coppa_service
    
    async def schedule_data_deletion(self, child_id: str, deletion_date: datetime) -> bool:
        """Schedule data deletion according to retention policy."""
        # Implementation would schedule deletion
        return True
    
    async def check_retention_compliance(self, child_id: str) -> dict:
        """Check if data retention is compliant."""
        return {
            "compliant": True,
            "retention_days": 90,
            "next_review": datetime.now()
        }

# Dependency injection
def get_compliance_validator(
    settings: Settings = Depends(get_settings)
) -> ComplianceValidator:
    """Get compliance validator instance."""
    return ComplianceValidator(settings)

def get_consent_manager() -> ParentalConsentManager:
    """Get consent manager instance."""
    coppa = COPPACompliance()
    return ParentalConsentManager(coppa)

def get_retention_manager() -> DataRetentionManager:
    """Get data retention manager instance."""
    coppa = COPPACompliance()
    return DataRetentionManager(coppa)

# API Endpoints
@router.post("/consent", response_model=ConsentResponse)
async def request_consent(
    request: ConsentRequest,
    consent_manager: ParentalConsentManager = Depends(get_consent_manager)
) -> ConsentResponse:
    """Request parental consent for data collection."""
    consent_id = await consent_manager.create_consent_record(
        request.child_id,
        request.parent_id,
        request.data_types
    )
    
    return ConsentResponse(
        consent_id=consent_id,
        status="pending",
        expires_at=datetime.now()
    )

@router.get("/compliance/age/{age}")
async def check_age_compliance(
    age: int,
    validator: ComplianceValidator = Depends(get_compliance_validator)
) -> dict:
    """Check compliance requirements for given age."""
    return validator.validate_age_compliance(age)
