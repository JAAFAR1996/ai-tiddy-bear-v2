"""Security Headers Middleware - Refactored
Provides comprehensive security headers for web application protection
"""

import logging
from dataclasses import dataclass, field

from fastapi import Request, Response
from fastapi.middleware.base import BaseHTTPMiddleware

logger = logging.getLogger(__name__)


@dataclass
class CSPConfig:
    """Content Security Policy configuration"""

    default_src: list[str] = field(default_factory=lambda: ["'self'"])
    script_src: list[str] = field(default_factory=lambda: ["'self'", "'unsafe-inline'"])
    style_src: list[str] = field(default_factory=lambda: ["'self'", "'unsafe-inline'"])
    img_src: list[str] = field(default_factory=lambda: ["'self'", "data:", "blob:"])
    connect_src: list[str] = field(default_factory=lambda: ["'self'"])
    font_src: list[str] = field(default_factory=lambda: ["'self'"])
    object_src: list[str] = field(default_factory=lambda: ["'none'"])
    media_src: list[str] = field(default_factory=lambda: ["'self'"])
    frame_src: list[str] = field(default_factory=lambda: ["'none'"])
    child_src: list[str] = field(default_factory=lambda: ["'none'"])
    worker_src: list[str] = field(default_factory=lambda: ["'self'"])
    manifest_src: list[str] = field(default_factory=lambda: ["'self'"])
    form_action: list[str] = field(default_factory=lambda: ["'self'"])
    frame_ancestors: list[str] = field(default_factory=lambda: ["'none'"])
    base_uri: list[str] = field(default_factory=lambda: ["'self'"])
    upgrade_insecure_requests: bool = True
    block_all_mixed_content: bool = True

    def to_header_value(self) -> str:
        """Convert CSP config to header value string"""
        directives = []

        if self.default_src:
            directives.append(f"default-src {' '.join(self.default_src)}")
        if self.script_src:
            directives.append(f"script-src {' '.join(self.script_src)}")
        if self.style_src:
            directives.append(f"style-src {' '.join(self.style_src)}")
        if self.img_src:
            directives.append(f"img-src {' '.join(self.img_src)}")
        if self.connect_src:
            directives.append(f"connect-src {' '.join(self.connect_src)}")
        if self.font_src:
            directives.append(f"font-src {' '.join(self.font_src)}")
        if self.object_src:
            directives.append(f"object-src {' '.join(self.object_src)}")
        if self.media_src:
            directives.append(f"media-src {' '.join(self.media_src)}")
        if self.frame_src:
            directives.append(f"frame-src {' '.join(self.frame_src)}")
        if self.child_src:
            directives.append(f"child-src {' '.join(self.child_src)}")
        if self.worker_src:
            directives.append(f"worker-src {' '.join(self.worker_src)}")
        if self.manifest_src:
            directives.append(f"manifest-src {' '.join(self.manifest_src)}")
        if self.form_action:
            directives.append(f"form-action {' '.join(self.form_action)}")
        if self.frame_ancestors:
            directives.append(f"frame-ancestors {' '.join(self.frame_ancestors)}")
        if self.base_uri:
            directives.append(f"base-uri {' '.join(self.base_uri)}")

        if self.upgrade_insecure_requests:
            directives.append("upgrade-insecure-requests")
        if self.block_all_mixed_content:
            directives.append("block-all-mixed-content")

        return "; ".join(directives)


@dataclass
class SecurityHeadersConfig:
    """Configuration for all security headers"""

    # Content Security Policy
    csp: CSPConfig | None = field(default_factory=CSPConfig)

    # Strict Transport Security
    hsts_enabled: bool = True
    hsts_max_age: int = 31536000  # 1 year
    hsts_include_subdomains: bool = True
    hsts_preload: bool = True

    # X-Frame-Options
    x_frame_options: str = "DENY"

    # X-Content-Type-Options
    x_content_type_options: str = "nosniff"

    # X-XSS-Protection
    x_xss_protection: str = "1; mode=block"

    # Referrer Policy
    referrer_policy: str = "strict-origin-when-cross-origin"

    # Permissions Policy
    permissions_policy: dict[str, list[str]] = field(
        default_factory=lambda: {
            "camera": ["'none'"],
            "microphone": ["'self'"],  # Allow microphone for voice features
            "geolocation": ["'none'"],
            "payment": ["'none'"],
            "usb": ["'none'"],
            "accelerometer": ["'none'"],
            "gyroscope": ["'none'"],
            "magnetometer": ["'none'"],
            "clipboard-read": ["'none'"],
            "clipboard-write": ["'self'"],
            "fullscreen": ["'self'"],
            "speaker-selection": ["'self'"],
        }
    )

    # Cross-Origin Embedder Policy
    coep_enabled: bool = False  # Disabled by default as it can break functionality
    coep_value: str = "require-corp"

    # Cross-Origin Opener Policy
    coop_enabled: bool = True
    coop_value: str = "same-origin"

    # Cross-Origin Resource Policy
    corp_enabled: bool = True
    corp_value: str = "same-origin"

    # Custom headers
    custom_headers: dict[str, str] = field(default_factory=dict)


def get_production_config() -> SecurityHeadersConfig:
    """Get production-ready security configuration"""
    csp = CSPConfig(
        default_src=["'self'"],
        script_src=["'self'", "'wasm-unsafe-eval'"],  # For WASM modules
        style_src=["'self'", "'unsafe-inline'"],  # Minimal inline styles
        img_src=["'self'", "data:", "blob:"],
        connect_src=["'self'", "wss:", "https:"],  # WebSocket and HTTPS APIs
        font_src=["'self'", "https://fonts.gstatic.com"],
        object_src=["'none'"],
        media_src=["'self'", "blob:"],  # For recorded audio
        frame_src=["'none'"],
        child_src=["'none'"],
        worker_src=["'self'"],
        form_action=["'self'"],
        frame_ancestors=["'none'"],
        base_uri=["'self'"],
        upgrade_insecure_requests=True,
        block_all_mixed_content=True,
    )

    return SecurityHeadersConfig(
        csp=csp,
        hsts_enabled=True,
        hsts_max_age=63072000,  # 2 years for production
        hsts_include_subdomains=True,
        hsts_preload=True,
        x_frame_options="DENY",
        x_content_type_options="nosniff",
        x_xss_protection="1; mode=block",
        referrer_policy="strict-origin-when-cross-origin",
        coep_enabled=False,  # May break audio processing
        coop_enabled=True,
        corp_enabled=True,
        custom_headers={
            "X-Robots-Tag": "noindex, nofollow",  # Prevent search indexing
            "Cache-Control": "no-store, no-cache, must-revalidate, private",
            "Pragma": "no-cache",
            "Expires": "0",
        },
    )


def get_development_config() -> SecurityHeadersConfig:
    """Get development-friendly security configuration"""
    csp = CSPConfig(
        default_src=["'self'"],
        script_src=["'self'", "'unsafe-inline'", "'unsafe-eval'"],  # Relaxed for dev
        style_src=["'self'", "'unsafe-inline'"],
        img_src=["'self'", "data:", "blob:", "*"],  # Allow all images in dev
        connect_src=["'self'", "ws:", "wss:", "*"],  # Allow all connections
        font_src=["'self'", "*"],
        object_src=["'none'"],
        media_src=["'self'", "blob:", "*"],
        frame_src=["'self'"],  # Allow frames in dev
        child_src=["'self'"],
        worker_src=["'self'"],
        form_action=["'self'"],
        frame_ancestors=["'self'"],
        base_uri=["'self'"],
        upgrade_insecure_requests=False,  # Don't upgrade in dev
        block_all_mixed_content=False,
    )

    return SecurityHeadersConfig(
        csp=csp,
        hsts_enabled=False,  # Disabled for development
        x_frame_options="SAMEORIGIN",
        coep_enabled=False,
        coop_enabled=False,
        corp_enabled=False,
        custom_headers={
            "X-Development-Mode": "true",
        },
    )


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    """Middleware to add comprehensive security headers"""

    def __init__(
        self,
        app,
        config: SecurityHeadersConfig | None = None,
        environment: str = "production",
    ):
        super().__init__(app)

        if config is None:
            if environment == "development":
                config = get_development_config()
            else:
                config = get_production_config()

        self.config = config
        logger.info(f"Security headers middleware initialized for {environment}")

    async def dispatch(self, request: Request, call_next) -> Response:
        """Add security headers to response"""
        response = await call_next(request)

        # Content Security Policy
        if self.config.csp:
            response.headers["Content-Security-Policy"] = (
                self.config.csp.to_header_value()
            )

        # HTTP Strict Transport Security
        if self.config.hsts_enabled:
            hsts_value = f"max-age={self.config.hsts_max_age}"
            if self.config.hsts_include_subdomains:
                hsts_value += "; includeSubDomains"
            if self.config.hsts_preload:
                hsts_value += "; preload"
            response.headers["Strict-Transport-Security"] = hsts_value

        # X-Frame-Options
        response.headers["X-Frame-Options"] = self.config.x_frame_options

        # X-Content-Type-Options
        response.headers["X-Content-Type-Options"] = self.config.x_content_type_options

        # X-XSS-Protection
        response.headers["X-XSS-Protection"] = self.config.x_xss_protection

        # Referrer Policy
        response.headers["Referrer-Policy"] = self.config.referrer_policy

        # Permissions Policy
        if self.config.permissions_policy:
            permissions = []
            for feature, allowlist in self.config.permissions_policy.items():
                if allowlist:
                    permissions.append(f"{feature}=({' '.join(allowlist)})")
                else:
                    permissions.append(f"{feature}=()")
            response.headers["Permissions-Policy"] = ", ".join(permissions)

        # Cross-Origin Embedder Policy
        if self.config.coep_enabled:
            response.headers["Cross-Origin-Embedder-Policy"] = self.config.coep_value

        # Cross-Origin Opener Policy
        if self.config.coop_enabled:
            response.headers["Cross-Origin-Opener-Policy"] = self.config.coop_value

        # Cross-Origin Resource Policy
        if self.config.corp_enabled:
            response.headers["Cross-Origin-Resource-Policy"] = self.config.corp_value

        # Custom headers
        for name, value in self.config.custom_headers.items():
            response.headers[name] = value

        return response


# Export for use in FastAPI applications
__all__ = [
    "CSPConfig",
    "SecurityHeadersConfig",
    "SecurityHeadersMiddleware",
    "get_development_config",
    "get_production_config",
]
