"""Security Headers Middleware - Refactored Entry Point
This module provides backward compatibility while delegating
to the new modular security headers implementation.
"""

from typing import Any

from src.infrastructure.logging_config import get_logger

from .security_headers import (
    CSPConfig,
    SecurityHeadersConfig,
    get_development_config,
    get_production_config,
)
from .security_headers import (
    SecurityHeadersMiddleware as NewSecurityHeadersMiddleware,
)

logger = get_logger(__name__, component="middleware")

# Backward compatibility alias
SecurityHeadersMiddleware = NewSecurityHeadersMiddleware


def create_security_headers_middleware(app, environment: str = "production"):
    """Create security headers middleware with environment-specific config

    Args:
        app: FastAPI application
        environment: Environment name (production, development, testing)

    Returns:
        Configured SecurityHeadersMiddleware instance
    """
    return SecurityHeadersMiddleware(app, environment=environment)


def get_middleware_stats(
    middleware: SecurityHeadersMiddleware,
) -> dict[str, Any]:
    """Get performance statistics from security middleware

    Args:
        middleware: SecurityHeadersMiddleware instance

    Returns:
        Dictionary with performance metrics
    """
    # Return basic stats - implement actual stats collection in the middleware
    return {
        "headers_applied": True,
        "environment": getattr(middleware, "environment", "unknown"),
        "config_loaded": middleware.config is not None,
    }


def create_child_safe_config() -> SecurityHeadersConfig:
    """Create configuration optimized for child safety and COPPA compliance"""
    config = get_production_config()

    # Enhanced child safety settings for CSP
    if config.csp:
        # Stricter CSP for children - no inline scripts or unsafe eval
        config.csp.script_src = ["'self'"]
        config.csp.object_src = ["'none'"]  # No plugins
        config.csp.frame_src = ["'none'"]  # No frames
        config.csp.child_src = ["'none'"]  # No child contexts
        config.csp.worker_src = ["'self'"]  # Only same-origin workers

        # Block potentially harmful content
        config.csp.font_src = ["'self'"]  # Only same-origin fonts
        config.csp.img_src = ["'self'", "data:"]  # Limited image sources
        config.csp.media_src = ["'self'", "blob:"]  # Audio/video from safe sources

        # Strict form and navigation policies
        config.csp.form_action = ["'self'"]
        config.csp.frame_ancestors = ["'none'"]  # Prevent embedding
        config.csp.base_uri = ["'self'"]

    # Enhanced security headers for child protection
    config.x_frame_options = "DENY"  # Prevent clickjacking
    config.referrer_policy = "no-referrer"  # Privacy protection

    # Permissions policy - restrict potentially dangerous features
    config.permissions_policy.update(
        {
            "camera": ["'none'"],  # No camera access
            "microphone": ["'self'"],  # Microphone only for voice features
            "geolocation": ["'none'"],  # No location access
            "payment": ["'none'"],  # No payment features
            "usb": ["'none'"],  # No USB access
            "accelerometer": ["'none'"],  # No motion sensors
            "gyroscope": ["'none'"],  # No gyroscope
            "magnetometer": ["'none'"],  # No magnetometer
            "clipboard-read": ["'none'"],  # No clipboard reading
            "clipboard-write": ["'none'"],  # No clipboard writing
            "fullscreen": ["'none'"],  # No fullscreen
            "picture-in-picture": ["'none'"],  # No PIP
            "screen-wake-lock": ["'none'"],  # No screen wake lock
            "web-share": ["'none'"],  # No web share API
        }
    )

    # Child protection custom headers
    config.custom_headers.update(
        {
            "X-Enhanced-Child-Protection": "enabled",
            "X-Parental-Control-Ready": "true",
            "X-Safe-Browsing": "enforced",
            "X-COPPA-Compliant": "true",
            "X-Child-Safe-Mode": "active",
            "X-Content-Filter": "strict",
            # Prevent caching of child data
            "Cache-Control": "no-store, no-cache, must-revalidate, private, max-age=0",
            "Pragma": "no-cache",
            "Expires": "Thu, 01 Jan 1970 00:00:00 GMT",
        }
    )

    return config


def create_development_safe_config() -> SecurityHeadersConfig:
    """Create development config that's still safe for testing with children"""
    config = get_development_config()

    # Keep some protections even in development
    if config.csp:
        config.csp.object_src = ["'none'"]  # Still block plugins
        config.csp.frame_ancestors = ["'none'"]  # Prevent embedding

    # Add development indicators
    config.custom_headers.update(
        {
            "X-Development-Mode": "true",
            "X-Child-Safe-Dev": "enabled",
        }
    )

    return config


# Convenience function for AI Teddy Bear project
def create_teddy_bear_middleware(app, environment: str = "production"):
    """Create middleware specifically configured for AI Teddy Bear application

    Args:
        app: FastAPI application
        environment: Environment (production/development)

    Returns:
        SecurityHeadersMiddleware configured for child safety
    """
    if environment == "production":
        config = create_child_safe_config()
    else:
        config = create_development_safe_config()

    logger.info(f"🧸 AI Teddy Bear security middleware initialized for {environment}")
    return SecurityHeadersMiddleware(app, config=config, environment=environment)


# Export the main classes for easy imports
__all__ = [
    "CSPConfig",
    "SecurityHeadersConfig",
    "SecurityHeadersMiddleware",
    "create_child_safe_config",
    "create_development_safe_config",
    "create_security_headers_middleware",
    "create_teddy_bear_middleware",
    "get_middleware_stats",
]

# Log the refactoring completion
logger.info(
    "✅ Security headers middleware refactored: Enhanced for child safety and COPPA compliance"
)
