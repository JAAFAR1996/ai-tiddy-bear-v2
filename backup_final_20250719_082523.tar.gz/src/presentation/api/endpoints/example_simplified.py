from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel

from src.infrastructure.di.fastapi_dependencies import (
    get_ai_service,
    get_child_service,
    get_conversation_service,
    get_current_parent,
    verify_child_access,
)
from src.infrastructure.logging_config import get_logger
from src.presentation.api.decorators.rate_limit import (
    moderate_limit,
    strict_limit,
)

logger = get_logger(__name__, component="api")

router = APIRouter(prefix="/api/v1", tags=["example"])


# Request/Response Models
class ChatRequest(BaseModel):
    child_id: str
    message: str


class ChatResponse(BaseModel):
    response: str
    child_safe: bool
    interaction_id: str


# Custom dependency function to verify child access
def create_child_access_dependency(child_id: str):
    """Create a dependency function that verifies access to a specific child."""

    async def verify_access(
        current_parent: dict[str, Any] = Depends(get_current_parent),
    ) -> bool:
        return await verify_child_access(child_id, current_parent)

    return verify_access


# Example Endpoints
@router.post("/chat", response_model=ChatResponse)
@moderate_limit()  # 30 requests per minute
async def chat_with_teddy(
    request: ChatRequest,
    current_parent: dict[str, Any] = Depends(get_current_parent),
    conversation_service=Depends(get_conversation_service),
):
    """Send a message to AI Teddy Bear."""
    try:
        # Verify child access first
        access_verified = await verify_child_access(request.child_id, current_parent)
        if not access_verified:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied to this child's data",
            )

        # Process chat message
        result = await conversation_service.process_message(
            child_id=request.child_id,
            message=request.message,
            parent_id=current_parent["user_id"],
        )

        return ChatResponse(
            response=result["response"],
            child_safe=result["is_safe"],
            interaction_id=result["interaction_id"],
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Chat processing error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to process chat message",
        )


@router.get("/children")
@moderate_limit()
async def get_my_children(
    current_parent: dict[str, Any] = Depends(get_current_parent),
    child_service=Depends(get_child_service),
) -> list[dict[str, Any]]:
    """Get all children for the current parent."""
    try:
        children = await child_service.get_children_by_parent(
            parent_id=current_parent["user_id"]
        )

        return [
            {
                "id": child.id,
                "name": child.name,
                "age": child.age,
                "avatar": child.avatar_url,
            }
            for child in children
        ]
    except Exception as e:
        logger.error(f"Error retrieving children: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve children data",
        )


@router.post("/children/{child_id}/story")
@strict_limit()  # 5 requests per minute (expensive operation)
async def generate_story(
    child_id: str,
    theme: str,
    current_parent: dict[str, Any] = Depends(get_current_parent),
    ai_service=Depends(get_ai_service),
    child_service=Depends(get_child_service),
):
    """Generate a personalized story for the child."""
    try:
        # Verify child access
        access_verified = await verify_child_access(child_id, current_parent)
        if not access_verified:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied to this child's data",
            )

        # Get child info
        child = await child_service.get_child(child_id)
        if not child:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Child not found",
            )

        # Generate story
        story = await ai_service.generate_story(
            child_name=child.name,
            child_age=child.age,
            theme=theme,
            safety_level="strict",
        )

        return {
            "story": story["content"],
            "reading_time": story["estimated_reading_time"],
            "age_appropriate": story["age_appropriate"],
            "child_id": child_id,
            "theme": theme,
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Story generation error: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to generate story",
        )


# Example of custom dependency
async def get_child_context(
    child_id: str,
    current_parent: dict[str, Any] = Depends(get_current_parent),
    child_service=Depends(get_child_service),
) -> dict[str, Any]:
    """Custom dependency that provides full child context."""
    try:
        # Verify access
        access_verified = await verify_child_access(child_id, current_parent)
        if not access_verified:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied to this child's data",
            )

        # Get child data
        child = await child_service.get_child(child_id)
        if not child:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Child not found",
            )

        # Get recent interactions
        interactions = await child_service.get_recent_interactions(child_id, limit=10)

        return {
            "child": child,
            "parent_id": current_parent["user_id"],
            "recent_interactions": interactions,
            "safety_settings": getattr(child, "safety_settings", {}),
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting child context: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve child context",
        )


@router.get("/children/{child_id}/context")
async def get_child_interaction_context(
    child_id: str,
    current_parent: dict[str, Any] = Depends(get_current_parent),
    child_service=Depends(get_child_service),
):
    """Get full context for child interactions."""
    try:
        # Get context using the dependency function
        context = await get_child_context(child_id, current_parent, child_service)

        return {
            "child_name": context["child"].name,
            "child_id": child_id,
            "recent_topics": [
                getattr(i, "topic", "Unknown") for i in context["recent_interactions"]
            ],
            "safety_level": context["safety_settings"].get("level", "standard"),
            "interaction_limits": context["safety_settings"].get("daily_limits", {}),
            "parent_id": context["parent_id"],
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting interaction context: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve interaction context",
        )


@router.get("/children/{child_id}/safety-settings")
@moderate_limit()
async def get_child_safety_settings(
    child_id: str,
    current_parent: dict[str, Any] = Depends(get_current_parent),
    child_service=Depends(get_child_service),
):
    """Get safety settings for a specific child."""
    try:
        # Verify access
        access_verified = await verify_child_access(child_id, current_parent)
        if not access_verified:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied to this child's data",
            )

        # Get child safety settings
        child = await child_service.get_child(child_id)
        if not child:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Child not found",
            )

        safety_settings = getattr(child, "safety_settings", {})

        return {
            "child_id": child_id,
            "safety_level": safety_settings.get("level", "standard"),
            "content_filters": safety_settings.get("content_filters", []),
            "time_limits": safety_settings.get("time_limits", {}),
            "allowed_topics": safety_settings.get("allowed_topics", []),
            "parental_controls": safety_settings.get("parental_controls", {}),
            "last_updated": safety_settings.get("last_updated"),
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrieving safety settings: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve safety settings",
        )


@router.get("/children/{child_id}/interactions/recent")
@moderate_limit()
async def get_recent_interactions(
    child_id: str,
    limit: int = 10,
    current_parent: dict[str, Any] = Depends(get_current_parent),
    child_service=Depends(get_child_service),
):
    """Get recent interactions for a specific child."""
    try:
        # Verify access
        access_verified = await verify_child_access(child_id, current_parent)
        if not access_verified:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied to this child's data",
            )

        # Get recent interactions
        interactions = await child_service.get_recent_interactions(
            child_id, limit=min(limit, 50)
        )  # Max 50 interactions

        return {
            "child_id": child_id,
            "interactions": [
                {
                    "id": getattr(interaction, "id", ""),
                    "timestamp": getattr(interaction, "timestamp", ""),
                    "type": getattr(interaction, "type", "chat"),
                    "topic": getattr(interaction, "topic", "General"),
                    "safety_score": getattr(interaction, "safety_score", 1.0),
                    "duration_seconds": getattr(interaction, "duration", 0),
                }
                for interaction in interactions
            ],
            "total_count": len(interactions),
            "limit": limit,
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrieving recent interactions: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve recent interactions",
        )
