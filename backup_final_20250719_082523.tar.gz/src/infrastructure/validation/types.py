"""Validation Types and Common Structures

Provides shared types and enums for the validation system.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


@dataclass
class ValidationResult:
    """Structured validation result with comprehensive metadata."""

    valid: bool
    sanitized_value: Any | None = None
    original_value: Any | None = None
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    security_flags: list[str] = field(default_factory=list)


class ValidationSeverity(Enum):
    """Validation issue severity levels."""

    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


class ValidationError(Exception):
    """Custom exception for validation errors.

    Provides structured error information for debugging and user feedback.
    """

    def __init__(
        self,
        message: str,
        field: str | None = None,
        code: str | None = None,
        severity: ValidationSeverity = ValidationSeverity.ERROR,
    ):
        super().__init__(message)
        self.message = message
        self.field = field
        self.code = code
        self.severity = severity

    def to_dict(self) -> dict[str, Any]:
        """Convert exception to dictionary for API responses."""
        return {
            "message": self.message,
            "field": self.field,
            "code": self.code,
            "severity": self.severity.value,
        }


# Common validation patterns
PATTERNS = {
    "email": r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$",
    "phone_us": r"^\(?([0-9]{3})\)?[-.\s]?([0-9]{3})[-.\s]?([0-9]{4})$",
    "url": r"^https?://[^\s/$.?#].[^\s]*$",
    "alphanumeric": r"^[a-zA-Z0-9]+$",
    "alpha_spaces": r"^[a-zA-Z\s]+$",
    "numeric": r"^\d+$",
}

# Age thresholds for COPPA compliance
AGE_THRESHOLDS = {
    "coppa_threshold": 13,
    "min_child_age": 3,
    "max_child_age": 17,
    "teen_threshold": 13,
    "adult_threshold": 18,
}

# Common length limits
LENGTH_LIMITS = {
    "name_min": 2,
    "name_max": 50,
    "email_max": 254,
    "message_max": 1000,
    "description_max": 500,
    "title_max": 100,
}

# Security patterns for detection
SECURITY_PATTERNS = {
    "xss": [
        r"<script[^>]*>.*?</script>",
        r"javascript:",
        r"vbscript:",
        r"onload\s*=",
        r"onerror\s*=",
        r"onclick\s*=",
    ],
    "sql_injection": [
        r"\bunion\s+select\b",
        r"\bselect\s+.*\bfrom\b",
        r"\binsert\s+into\b",
        r"\bdelete\s+from\b",
        r"\bdrop\s+table\b",
        r"[\'\"];.*--",
    ],
    "path_traversal": [
        r"\.\.\/",
        r"\.\.\w",
        r"\/\.\.",
        r"\w\.\.",
    ],
}
